# W02D05-HW

## Command Line / Interview Questions

### 1. Porftolio Project EST TIME: 5hr

1. Fork and Clone the [Portfolio Project repo](https://git.generalassemb.ly/SEIR-526/project-1-portfolio?organization=SEIR-526&organization=SEIR-526)
2. Add link to your project [here](https://docs.google.com/spreadsheets/d/1UnhpYCWFX9LxGuhoe5E1K74271K-VAcVojIuR0XM57A/edit?usp=sharing)
3. Begin working on the planning process for your project.
4. Monday morning you will meet with your Squad Lead for approval.  


### 2. Read/Watch The Following - EST TIME: 1hr
 - Read: [How To Efficiently Master CSS Grid In A Jiffy](https://medium.com/flexbox-and-grids/how-to-efficiently-master-the-css-grid-in-a-jiffy-585d0c213577) - 20min
 - Watch: [Corgi Carousel](https://youtu.be/TOjD8iX7hV0) - 40min


### 3. ALGO PRACTICE - EST TIME: 20min

None assigned at this time


### 4.  INTERVIEW PRACTICE - EST TIME: 20min

None assigned at this time
